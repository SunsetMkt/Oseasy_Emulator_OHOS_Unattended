To install
------------------------------------------------------------
Right-click one of the flavors of Install-XXX.bat and choose
"Run as administrator". If you don't know which flavor, use
"Install-x64.bat".

To uninstall
------------------------------------------------------------
Locate the Scream driver in device manager and uninstall it
there. Make sure to choose the "Remove driver software"
option when uninstalling.
